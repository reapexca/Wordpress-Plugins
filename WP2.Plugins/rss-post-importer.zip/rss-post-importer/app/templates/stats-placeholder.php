<table class="widefat rss_pi-table" id="rss_pi-table">
	<thead>
		<tr>
			<th><?php _e('Stats', 'rss_pi'); ?></th>
		</tr>
    </thead>
    <tbody class="setting-rows">
		<tr class="edit-row show">
			<td>
				<div id="rss_pi-stats-placeholder">
<script type="text/javascript"
	src="https://www.google.com/jsapi?autoload={
	'modules':[{
	'name':'visualization',
	'version':'1.1',
	'packages':['corechart' , 'bar']
	}]
}"></script>
				</div>
			</td>
		</tr>
	</tbody>
</table>
