<?php
$stats = new Rss_pi_stats();
$stats->show_charts();
