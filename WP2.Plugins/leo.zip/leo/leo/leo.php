<?php
/*
Plugin Name: Leo
Description: Site specific code changes for example.com
*/
/* Start Adding Functions Below this Line */


/* Disable WordPress Admin Bar for all users but admins. */
  show_admin_bar(false);

/* Stop Adding Functions Below this Line */
?>