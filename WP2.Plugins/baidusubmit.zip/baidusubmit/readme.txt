=== Baidu Sitemaps ===

Contributors: 百度
Tags: Baidu,XML,Sitemap
Requires at least: 1.0
Tested up to: 3.81
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Donate link: http://zhanzhang.baidu.com

百度Sitemap


== Description ==
After installing Baidu Sitemaps, you can quickly and completely submit webpages and content to Baidu. It helps you with the following:
1) Baidu Spider will better understand and include your site.
2) Baidu Search will better display results from your site.

安装百度Sitemap后，能又快又全的向百度提交网页及内容，有助于：
1）百度 Spider 更好地了解您的网站，优化收录
2）网站在百度搜索上得到更好展现
您还可以到 百度站长平台提交：<a href="http://zhanzhang.baidu.com/sitemap/index" target="_blank">sitemap</a> | <a href="http://zhanzhang.baidu.com/schema/index" target="_blank">结构化数据</a> | <a href="http://zhanzhang.baidu.com/badlink/index" target="_blank">死链提交</a>
使用过程中，有任何意见或建议请提至 百度站长反馈中心


== Screenshots ==

1. 百度Sitemap管理员面板截图


 == Frequently Asked Questions ==
暂无


== Installation ==

1. 上传 `baidusubmit` 目录到 `/wp-content/plugins/` 目录
2. 在 WordPress 插件面板激活 `百度Sitemap` 插件
3. 验证你的站点


== Upgrade Notice ==
暂无

== Changelog ==
暂无