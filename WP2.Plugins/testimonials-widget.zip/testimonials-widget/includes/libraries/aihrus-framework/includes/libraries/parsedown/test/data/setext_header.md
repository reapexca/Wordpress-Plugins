h1
==

h2
--

single character
-

not a header

------------