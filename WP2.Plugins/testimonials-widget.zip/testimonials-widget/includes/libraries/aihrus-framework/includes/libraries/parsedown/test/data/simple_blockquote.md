> quote

indented:
   > quote

no space after `>`:
>quote