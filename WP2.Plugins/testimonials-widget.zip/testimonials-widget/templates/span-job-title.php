<?php
global $tw_template_args;

$testimonial = $tw_template_args['testimonial'];
?>
<span class="job-title"><?php echo $testimonial['testimonial_title']; ?></span>
