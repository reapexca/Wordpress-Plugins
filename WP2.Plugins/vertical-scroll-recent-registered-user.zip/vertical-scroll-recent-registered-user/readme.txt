=== vertical scroll recent registered user ===
Contributors: www.gopiplus.com, gopiplus 
Donate link: http://www.gopiplus.com/work/2010/07/18/vertical-scroll-recent-registered-user/
Author URI: http://www.gopiplus.com/work/2010/07/18/vertical-scroll-recent-registered-user/
Plugin URI: http://www.gopiplus.com/work/2010/07/18/vertical-scroll-recent-registered-user/
Tags: vertical, scroll, recent, registered, plugin, widget
Requires at least: 3.4
Tested up to: 4.1
Stable tag: 7.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
	
Vertical scroll recent registered user wordpress plugin create the scroller in the widget with recently registered user avatar, username and date.

== Description ==

Check official website for live demo [http://www.gopiplus.com/work/2010/07/18/vertical-scroll-recent-registered-user/](http://www.gopiplus.com/work/2010/07/18/vertical-scroll-recent-registered-user/)

*  [Live Demo](http://www.gopiplus.com/work/2010/07/18/vertical-scroll-recent-registered-user/)		
*  [More info](http://www.gopiplus.com/work/2010/07/18/vertical-scroll-recent-registered-user/)			
*  [User Comments](http://www.gopiplus.com/work/2010/07/18/vertical-scroll-recent-registered-user/)	
*  [About author](http://www.gopiplus.com/work/)	

Vertical scroll recent registered user wordpress plugin create the scroller in the widget with recently registered user avatar, username and date. Check the live demo on sidebar. In the sidebar it's scrolling my recently registered user list. At present there is no user registration available in my website (disabled to avoid spam) so it its scrolling last 5 registered user list.

= Features of this plugin =

*   Smooth scroll.
*   Have option to display/hide avatar.
*   Have option to display/hide registered date.
*   Have option to display number of recent register user.
	
== Installation ==

[Installation Instruction and Configuration](http://www.gopiplus.com/work/2010/07/18/vertical-scroll-recent-registered-user/)

== Frequently Asked Questions ==

Q1. Is possible to stop display the registered date from scroll?

Q2. Is possible to stop display avatar from scroll?

Q3. Is possible to stop display avatar border from scroll?

Q4. What is "Display number of user at the same time in scroll" this in widget management area?

Q5. What is "Enter max number of user to display" this in widget management area?

[Answer](http://www.gopiplus.com/work/2010/07/18/vertical-scroll-recent-registered-user/)

== Screenshots ==

1. Front Screen. http://www.gopiplus.com/work/2010/07/18/vertical-scroll-recent-registered-user/

2. Admin Screen. http://www.gopiplus.com/work/2010/07/18/vertical-scroll-recent-registered-user/

== Upgrade Notice ==

= 7.4 =

1. Tested up to 4.1

= 7.3 =

1. Tested up to 4.0
2. Support multisite blogs.

= 7.2 =

1. Tested up to 3.9

= 7.1 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (vertical-scroll-recent-registered-user.po) available in the languages folder.

= 7.0 =

Tested up to 3.6

= 6.1 =

Tested up to 3.5

= 6.0 =

New demo link, http://www.gopiplus.com

= 5.0 =

Tested up to 3.4

= 4.0 =

Tested up to 3.3

= 3.0 =

Tested up to 3.1.3

= 2.0 =

Tested up to 3.0

= 1.0 =

First version.

== Changelog ==

= 7.4 =

1. Tested up to 4.1

= 7.3 =

1. Tested up to 4.0
2. Support multisite blogs. 

= 7.2 =

1. Tested up to 3.9

= 7.1 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (vertical-scroll-recent-registered-user.po) available in the languages folder.

= 7.0 =

Tested up to 3.6

= 6.1 =

Tested up to 3.5

= 6.0 =

New demo link, http://www.gopiplus.com

= 5.0 =

Tested up to 3.4

= 4.0 =

Tested up to 3.3

= 3.0 =

Tested up to 3.1.3

= 2.0 =

Tested up to 3.0

= 1.0 =

First version.