Affiliates Pro                                        Copyright www.itthinx.com
s2Member Integration Pack                            Email: itthinx@itthinx.com
                                                              Twitter: @itthinx


            Thank you for contributing to the Affiliates plugin series.

              Please get in touch if you need help or have questions.

                        Your feedback is highly appreciated.

 =============================================================================
  
  You MUST be granted a license by the copyright holder for those parts that
  are not provided under the GPLv3 license.
  
  If you have not been granted a license DO NOT USE this plugin until you have
  BEEN GRANTED A LICENSE.
  
  Use of this plugin without a granted license constitutes an act of COPYRIGHT
  INFRINGEMENT and LICENSE VIOLATION and may result in legal action taken
  against the offending party.
  
  Being granted a license is GOOD because you will get support and contribute
  to the development of useful free and premium themes and plugins that you
  will be able to enjoy.
  
  Thank you!
  
  Visit www.itthinx.com for more information.
 
 =============================================================================

===============================================================================

    Table of Contents

    1) Files
    2) Installation
    3) Setup
    4) Update
    5) Documentation
    
===============================================================================

1) Files
===============================================================================

This integration pack contains three files:

    README.txt              - this readme file
    affiliates-pro.zip      - the Affiliates Pro plugin
    affiliates-s2member.zip - the Affiliates s2Member Integration plugin

2) Installation
===============================================================================

To install the Affiliates Pro integration pack, please follow these steps:

    2.1) Backup
    ---------------------------------------------------------------------------

    Back up your WordPress installation files and database.

    2.2) Deactivate Affiliates
    ---------------------------------------------------------------------------

    This step applies only if you have been using the free Affiliates plugin.

    IMPORTANT: Make sure that the "Delete all plugin data on deactivation"
    option is not checked if you want to maintain your current settings and
    data.

    Go to "Plugins" and click Deactivate to disable your current Affiliates
    plugin. Then click on Delete to remove it.
   
    2.3) Add and activate plugins
    ---------------------------------------------------------------------------
    
    1. Add the s2Member plugin.
    
       Only if you have not yet installed and activated the
       s2Member plugin:
    
       Go to "Plugins > Add New" and use Search to locate the "s2Member"
       plugin or download it from http://wordpress.org/extend/plugins/s2member
       and upload it to your site.
    
       Now activate the s2Member plugin. 

    2. Add the (new) Affiliates Pro plugin and activate it:

       Go to "Plugins > Add New > Upload" and click the "Browse..." button to
       select the plugin's zip file, usually affiliates-pro.zip and click on
       the "Install Now" button.

       After that proceed to activate the plugin.

    3. Add the (new) integration plugin:

       Go to "Plugins > Add New > Upload" and click the "Browse..." button to
       select the plugin's zip file: affiliates-s2member.zip then click on the
       "Install Now" button.

       Now activate the integration plugin.

3) Setup
===============================================================================

    IMPORTANT: You must set up your s2Member options properly before referrals
    can be recorded.

    Affiliates s2Member Integration settings can be adjusted under
    "Affiliates > s2Member". Make sure to revise that all options are set as
    desired.
    
    3.1) s2Member API Notifications
    ---------------------------------------------------------------------------
    
    * Payment Notifications
    
    The Affiliates s2Member Integration automatically adjusts s2Member's
    payment notification URLs by default.
    
    * Refund/Reversal Notifications
    
    The Affiliates s2Member Integration automatically adjusts s2Member's
    refund/reversal notification URLs by default.

    3.2) Email notifications
    ---------------------------------------------------------------------------
    
    The Affiliates s2Member Integration notifies the site administrator and
    the affiliate of new referrals by default.
    
    The message sent to the affiliate can be customized.
    
    3.3) Subscriptions & referrals
    ---------------------------------------------------------------------------
    
    * Maintaining subscription referrals
    
    If you want to pay commissions for recurring payments to your affiliates,
    this option must be checked. If you offer monthly subscriptions and an
    affiliate refers a client, the affiliate will get credited with a referral
    each time a new payment for that subscription has been made.
    
    * Limit
    
    You can limit the above (referrals for recurring payments) to a number
    of days after the initial payment for the subscription has been made.
    The default value (0) means that there is no limit.
    
    3.4) Referral status and auto-adjustments
    ---------------------------------------------------------------------------
    
    If you want to reject referrals that when a payment is refunded or
    reversed, this option will take care of it automatically.

4) Update
===============================================================================

    4.1) Backup
    ---------------------------------------------------------------------------

    Back up your WordPress installation files and database.

    4.2) Upgrade to the latest release
    ---------------------------------------------------------------------------
    
    Upgrading requires to replace two plugins:
    
    - Affiliates Pro
    - Affiliates s2Member Integration
    
    IMPORTANT: Make sure that the "Delete all plugin data on deactivation"
    option is not checked if you want to maintain your current settings and
    data.
    
    In each case, the plugin must be deactivated, deleted and the new release
    uploaded and activated. These are the steps involved:
    
    1. Go to "Plugins > Installed Plugins", click Deactivate on the
       "Affiliates s2Member Integration" plugin, then click Delete to
       remove it.
    
    2. Go to "Plugins > Installed Plugins", click Deactivate on the
       "Affiliates Pro" plugin, then click Delete to remove it.
    
    3. Go to "Plugins > Add New > Upload" and click the "Browse..." button to
       select the new release's zip file, usually affiliates-pro.zip and click
       on the "Install Now" button. After it has been installed, activate the
       plugin.
    
    4. Go to "Plugins > Add New > Upload" and click the "Browse..." button to
       select the new release's zip file: affiliates-s2member.zip, click the
       "Install Now" button and after it has been installed, activate the
       plugin.
    
5) Documentation
===============================================================================

    The full documentation for the Affiliates plugins is located at:
    
    http://www.itthinx.com/documentation/affiliates
    
    Complementary information is available here:
    
    http://www.itthinx.com/plugins/affiliates
    http://www.itthinx.com/plugins/affiliates-pro
    http://www.itthinx.com/plugins/affiliates-enterprise
    http://www.itthinx.com/plugins/affiliates-s2member
