<div id="sendgrid_statistics_deliveries_widget" class="postbox">
  <h3 class="hndle"><span>SendGrid Deliveries</span></h3>
  <div class="inside">

    <div class="sendgrid-container" style="position:relative;">
      <img src="<?php echo plugin_dir_url( __FILE__ ); ?>../images/loader.gif" class="loading" style="position:absolute;" />
      <div id="deliveries-container" class="sendgrid-statistics"></div>
    </div>
    <div id="deliveries-container-legend" class="sendgrid-statistics-legend"></div> 

  </div>
</div>
